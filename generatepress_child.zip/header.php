<!DOCTYPE html>
<html lang="es">

<head>
  <?php
  wp_head();
  ?>
</head>

<body class="bg-amber-300">

  <header class="bg-green-300 text-white font-bold">
    cabecera
  </header>