<?php

/**
 * Template Name: Categorías
 * Template para mostrar los posts de todas las categorías
 *
 */

get_header(); ?>
<?php get_template_part('partials/post-producto/posts') ?>

<?php get_footer(); ?>