<?php
/* Template Name: Sostenibilidad */

get_header();

get_template_part("partials/pages/sostenibilidad/sostenibilidad");

get_footer();
