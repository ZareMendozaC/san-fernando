<?php
/* Template Name: Prensa Detalle */

get_header();

get_template_part("partials/pages/prensa/prensadetalle");

get_footer();