<?php
/* Template Name: Politicas de privacidad */

get_header();

get_template_part("partials/pages/politicas/politicasdeprivacidad");

get_footer();
