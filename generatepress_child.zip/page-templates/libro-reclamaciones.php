<?php
/* Template Name: Libro Reclamaciones */

get_header();

get_template_part("partials/pages/reclamaciones/libroreclamaciones");

get_footer();
