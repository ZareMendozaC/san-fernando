<?php
/* Template Name: Contactanos */

get_header();

get_template_part("partials/pages/contactanos/contactanos");

get_footer();
