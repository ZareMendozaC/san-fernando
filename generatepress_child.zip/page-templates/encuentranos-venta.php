<?php
/* Template Name: Puntos de venta */

get_header();

get_template_part("partials/pages/encuentranos/encuentranos_venta");

get_footer();