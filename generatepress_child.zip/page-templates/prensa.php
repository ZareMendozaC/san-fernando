<?php
/* Template Name: Prensa */

get_header();

get_template_part("partials/pages/prensa/prensa");

get_footer();