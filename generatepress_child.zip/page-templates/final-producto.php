<?php
/* Template Name: Producto Detalle final */

get_header();

get_template_part("partials/pages/producto/finalproducto");

get_footer();
