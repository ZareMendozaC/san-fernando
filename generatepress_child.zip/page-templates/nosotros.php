<?php
/* Template Name: Nosotros */

get_header();

get_template_part("partials/pages/nosotros");

get_footer();