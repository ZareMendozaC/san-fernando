<?php
/* Template Name: Inicio */

get_header();

get_template_part("partials/pages/inicio");

get_footer();