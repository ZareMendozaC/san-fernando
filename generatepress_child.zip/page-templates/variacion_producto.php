<?php
/* Template Name: Variacion producto */

get_header();

get_template_part("partials/pages/producto/variacion_producto");

get_footer();