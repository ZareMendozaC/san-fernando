<?php
/* Template Name: Puntos de canje */

get_header();

get_template_part("partials/pages/encuentranos/encuentranos");

get_footer();