<?php
/* Template Name: Productos */

get_header();

get_template_part("partials/pages/productos");

get_footer();