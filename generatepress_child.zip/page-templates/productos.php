<?php
/* Template Name: Productos */

get_header();

get_template_part("partials/pages/producto/productos");

get_footer();