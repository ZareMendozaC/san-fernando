<?php
/* Template Name: Campañas */

get_header();

get_template_part("partials/pages/campañas");

get_footer();