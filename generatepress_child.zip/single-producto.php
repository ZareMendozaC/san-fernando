<?php

/**
 * Template Name: Detalle productos final
 * Template para mostrar detalle de los productos
 *
 */

get_header(); ?>
<?php get_template_part('partials/post-producto/finalproducto') ?>

<?php get_footer(); ?>