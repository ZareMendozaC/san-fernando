<?php
//$categories = get_categories();
//$request_category = get_queried_object();
//$search_query = get_search_query();

?>